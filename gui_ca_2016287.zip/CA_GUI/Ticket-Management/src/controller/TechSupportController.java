package controller;

import helper.Utils;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.JOptionPane;

import view.CreateTicketView;
import view.TechSupportView;
import model.Ticket;
import model.User;

public class TechSupportController extends MainController {
	private List<Ticket> tickets;
	
	public TechSupportController(User user) {
		super(user);
	}

	public void initController() {
		view = new TechSupportView();
		super.initController();
		fetchTickets();
		view.setVisible(true);
		TechSupportView techView = (TechSupportView) view;
		techView.refreshList(tickets);
		techView.getButton("create").addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				createTicket();
			}
		});

		techView.getButton("refresh").addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				fetchTickets();
				((TechSupportView) view).refreshList(tickets);
			}
		});
		
		techView.getButton("delete").addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				deleteTickets(techView.getSelectedTicketIndex());
				fetchTickets();
				((TechSupportView) view).refreshList(tickets);
			}
		});
	}

	protected void deleteTickets(int[] index) {
		if(index != null && index.length > 0) {
			for (int i : index) {
				if(i >= 0 && i < tickets.size()) {
					ticketDao.deleteTicket(tickets.get(i).getTicketId());
				}
			}
		}
	}

	protected boolean saveTicket(Ticket t) {		
		return ticketDao.createTicket(t);
	}

	protected void createTicket() {
		Ticket ticket = new Ticket();
		CreateTicketView createView = new CreateTicketView(ticket);
		createView.setVisible(true);
		createView.getBtnSave().addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Ticket ticket = createView.getTicket();
				ticket.setTicketStatus("open");
				ticket.setOpened(Utils.getCurrentTimeStamp());
				if(saveTicket(ticket)) {
					JOptionPane.showMessageDialog(null, "Ticket is created.");
					createView.dispose();
					fetchTickets();
					((TechSupportView) view).refreshList(tickets);
				} else {
					JOptionPane.showMessageDialog(null, "Ticket creation is failed");
				}
			}
		});
		createView.getBtnCancel().addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				createView.dispose();
			}
		});
	}

	private void fetchTickets() {
		System.out.println("Fetching Tickets..");
		tickets = ticketDao.getAllTickets();
	}
}
