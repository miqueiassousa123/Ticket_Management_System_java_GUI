package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;

import view.MainView;
import main.TicketManagementSystem;
import model.User;
import dao.TicketDao;

public class MainController {
	protected TicketDao ticketDao;
	protected User user;
	protected MainView view;
	
	public MainController(User user) {
		this.user = user;
		ticketDao = new TicketDao();
	}
	
	public void initController() {
		if(view != null) {
			view.getButton("logout").addActionListener(new ActionListener() {
    			public void actionPerformed(ActionEvent arg0) {
    				logout();
    			}
    			});
		}
	}
	
	public void logout() {
		int reply = JOptionPane.showConfirmDialog(this.view, "Are you sure you want to logout?", "Logout", JOptionPane.YES_NO_OPTION);
        if (reply == JOptionPane.YES_OPTION) {
          this.view.dispose();
          TicketManagementSystem.main(null);
        }
        else {
           //do nothing
        }
	}


	public MainView getView() {
		return view;
	}


	public void setView(MainView view) {
		this.view = view;
	}
}
