package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import model.User;
import view.LoginView;
import dao.UserDao;


public class LoginContoller {
	private UserDao userDao;
	private User model;
	private LoginView view;
       
	public LoginContoller(){
		userDao = new UserDao();
    	model = new User();
    }
	
    public LoginContoller(LoginView view){
    	this();
        setView(view);
    }
    
    public LoginContoller(String userName, String password){
    	this();
    	model.setUserName(userName);
    	model.setPassword(password);
    }
    
    private void initView() {    	  
        view.setModel(model);
	}

	public void initController() {
    	if(view != null) {
        	view.getButton("login").addActionListener(new ActionListener() {
    			public void actionPerformed(ActionEvent arg0) {
    				login();
    			}
    		});
        	view.setVisible(true);
        }
	}

	protected void proceedNext(User user) {
		int role = user.getRole();
		view.dispose();
		switch(role) {
			case 1:
				new TechSupportController(user).initController();
				break;
			case 2:
				new AdminController(user).initController();
				break;
			case 3:
				new ManagerController(user).initController();
				break;
			default:
				new TechSupportController(user).initController();
				break;
		}
	}

	public void login() {
    	model = view.getModel();
        User user = userDao.loginUser(model.getUserName(), model.getPassword());
		if(user != null) {
			proceedNext(user);
		}
    }

	public User getModel() {
		return model;
	}

	public void setModel(User model) {
		this.model = model;
		view.setModel(model);
	}

	public LoginView getView() {
		return view;
	}

	public void setView(LoginView view) {
		this.view = view;
		initView();
	}
    
}
