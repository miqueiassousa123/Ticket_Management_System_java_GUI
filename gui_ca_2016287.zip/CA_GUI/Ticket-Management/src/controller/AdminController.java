package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.JOptionPane;

import model.User;
import view.AdminView;
import dao.UserDao;

public class AdminController extends MainController{	
	private List<User> users;
	private AdminView adminView;
	private UserDao userDao;
	public AdminController(User user) {
		super(user);
		userDao = new UserDao();
	}
	
	public void initController() {
		view = new AdminView();
		super.initController();
		fetchUsers();
		view.setVisible(true);
		adminView = (AdminView) view;
		adminView.refreshList(users);
		adminView.getButton("create").addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				createUser();
			}
		});
		
		adminView.getButton("delete").addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				deleteUser();
			}
		});
		
		adminView.getButton("update").addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				updateUser();
			}
		});

		adminView.getButton("refresh").addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				fetchUsers();
				adminView.refreshList(users);
			}
		});
	}

	protected void deleteUser() {
		int selectedIndex = adminView.getSelectedUserIndex();
		if(selectedIndex >= 0 && selectedIndex < users.size()) {
			users.get(selectedIndex).getId();
			if(userDao.deleteUser(users.get(selectedIndex))) {
				fetchUsers();
				adminView.refreshList(users);
			} else {
				JOptionPane.showMessageDialog(null, "User deletion failed");
			}
		} else {
			JOptionPane.showMessageDialog(null, "Please select an user to delete");
		}
	}

	protected void createUser() {
		user = adminView.getUser();
		if(userDao.createUser(user)) {
			fetchUsers();
			adminView.refreshList(users);
		} else {
			JOptionPane.showMessageDialog(null, "User creation failed");
		}
		
	}

	protected void updateUser() {
		int selectedIndex = adminView.getSelectedUserIndex();
		if(selectedIndex >= 0 && selectedIndex < users.size()) {
			user = adminView.getUser();
			user.setId(users.get(selectedIndex).getId());
			if(userDao.updateUser(user)) {
				fetchUsers();
				adminView.refreshList(users);
			} else {
				JOptionPane.showMessageDialog(null, "User update failed");
			}
		} else {
			JOptionPane.showMessageDialog(null, "Please select an user to update");
		}
	}

	private void fetchUsers () {
		System.out.println("Fetching Users..");
		users = userDao.getAllUsers();
	}
}
