package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import javax.swing.JOptionPane;

import model.TeamSummary;
import model.Ticket;
import model.TicketSummary;
import model.User;
import view.ManagerView;
import view.Stats;
import view.StatusView;
import view.TeamView;

public class ManagerController extends MainController {
	private List<Ticket> tickets;
	private ManagerView managerView;
	public ManagerController(User user) {
		super(user);
	}
	public void initController() {
		view = new ManagerView();
		super.initController();
		fetchTickets();
		view.setVisible(true);
		managerView = (ManagerView) view;
		managerView.refreshList(tickets);
		managerView.getButton("team").addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				showTeamStatus();
			}
		});
		
		managerView.getButton("status").addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				showStatusSummary();
			}
		});
		
		managerView.getButton("diagram").addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				showDiagram();
			}
		});

		managerView.getButton("refresh").addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				fetchTickets();
				managerView.refreshList(tickets);
			}
		});
		
		managerView.getButton("close").addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				closeTickets(managerView.getSelectedTicketIndex());
				fetchTickets();
				managerView.refreshList(tickets);
			}
		});
	}
        
        protected void showDiagram() {
            TicketSummary ticketSummary = ticketDao.getTicketSummary();
            System.out.println(ticketSummary.getNoTotal() + ", " + ticketSummary.getNoOpen() + ", " + ticketSummary.getNoClose());
            JOptionPane.showConfirmDialog(null, new Stats(new int[]{ticketSummary.getNoTotal()
                        , ticketSummary.getNoOpen()
                        , ticketSummary.getNoClose()}), "Manager Interface",
                JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        }

	protected void showStatusSummary() {
		TicketSummary ticketSummary = ticketDao.getTicketSummary();
		StatusView statusView = new StatusView(ticketSummary);
		statusView.setVisible(true);
	}
	
	protected void showTeamStatus() {
		List<TeamSummary> team = ticketDao.getTeamSummary();
		TeamView teamView = new TeamView(team);
		teamView.setVisible(true);
	}
	
	protected void closeTickets(int[] index) {
		if(index != null && index.length > 0) {
			for (int i : index) {
				if(i >= 0 && i < tickets.size()) {
					Ticket ticket = tickets.get(i);
					if("open".equalsIgnoreCase(ticket.getTicketStatus())) {
						ticketDao.closeTicket(ticket.getTicketId());
					}
				}
			}
		}
	}

	private void fetchTickets() {
		System.out.println("Fetching Tickets..");
		tickets = ticketDao.getAllTickets();
	}
}
