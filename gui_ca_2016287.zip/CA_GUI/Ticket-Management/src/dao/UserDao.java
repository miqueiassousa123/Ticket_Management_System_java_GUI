package dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import java.util.Vector;

import model.User;


public class UserDao {
    public User loginUser(String username, String password) {
        ResultSet rs = null;
        Connection connection = null;
        Statement statement = null; 
        
        String sql = "select * from users where username='" + username + "' and password='" + password + "'";
        
        try {			
            connection = ConnectionManager.getConnection();
            statement = connection.createStatement();
            rs = statement.executeQuery(sql);
            
            if(rs.next()) {
            	User user = new User();
            	user.setUserName(rs.getString("username"));
            	user.setRole(rs.getInt("role"));
            	user.setPassword(rs.getString("password"));
            	user.setId(rs.getLong("user_id"));
                return user;
            }
            
        } catch (SQLException e) {
                e.printStackTrace();
        } finally {
            if (connection != null) {
                try {
                        connection.close();
                } catch (SQLException e) {
                        e.printStackTrace();
                }
            }
        }
        return null;
    }
    
    public int getRoleOfUser(String username) {
        ResultSet rs = null;
        Connection connection = null;
        Statement statement = null; 
        
        String sql = "select * from users where username='" + username + "'";
        
        try {			
            connection = ConnectionManager.getConnection();
            statement = connection.createStatement();
            rs = statement.executeQuery(sql);
            
            if(rs.next()) {
                return rs.getInt("role");
            }
            
        } catch (SQLException e) {
                e.printStackTrace();
        } finally {
            if (connection != null) {
                try {
                        connection.close();
                } catch (SQLException e) {
                        e.printStackTrace();
                }
            }
        }
        return -1;
    }
    
    public boolean createUser(String userName, String password, int role) {
        User u = new User();
        u.setUserName(userName);
        u.setPassword(password);
        u.setRole(role);
        return createUser(u);
    }
    
    public boolean resetPassword(String username, String password) {
        Connection connection = null;
        Statement statement = null; 
        String sql = "update users set password='" + password + "' where username='" + username +"'";
        try {			
            connection = ConnectionManager.getConnection();
            statement = connection.createStatement();
            int i = statement.executeUpdate(sql);
            if(i > 0){
                  return true;
            }
            else {
                 return false;
            }
        } catch (SQLException e) {
                e.printStackTrace();
        } finally {
            if (connection != null) {
                try {
                        connection.close();
                } catch (SQLException e) {
                        e.printStackTrace();
                }
            }
        }
        return false;
    }

	public List<User> getAllUsers() {
		
		ResultSet rs = null;
		Connection connection = null;
		Statement statement = null;
		Vector<User> users = new Vector<User>();

		String sql = "select * from users";

		try {
			connection = ConnectionManager.getConnection();
			statement = connection.createStatement();
			rs = statement.executeQuery(sql);

			while (rs.next()) {
				User user = new User();
				user.setId(rs.getInt("user_id"));
				user.setUserName(rs.getString("username"));
				user.setPassword(rs.getString("password"));
				user.setRole(rs.getInt("role"));
				users.add(user);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (connection != null) {
				try {
					connection.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return users;
	}

	public boolean createUser(User user) {
		Connection connection = null;
        Statement statement = null; 
        String sql = "insert into users  (username, password, role) values ('" +user.getUserName()+ "', '" + user.getPassword() + "', " + user.getRole() + ")";
        try {			
            connection = ConnectionManager.getConnection();
            statement = connection.createStatement();
            int i = statement.executeUpdate(sql);
            if(i > 0){
                  return true;
            }
            else {
                 return false;
            }
        } catch (SQLException e) {
                e.printStackTrace();
        } finally {
            if (connection != null) {
                try {
                        connection.close();
                } catch (SQLException e) {
                        e.printStackTrace();
                }
            }
        }
        return false;
	}

	public boolean updateUser(User user) {
		Connection connection = null;
        Statement statement = null; 
        String sql = "update users  set username = '" +user.getUserName()+ "', password = '" + user.getPassword() + "' , role = " + user.getRole() + " where user_id = " + user.getId();
        try {			
            connection = ConnectionManager.getConnection();
            statement = connection.createStatement();
            int i = statement.executeUpdate(sql);
            if(i > 0){
                  return true;
            }
            else {
                 return false;
            }
        } catch (SQLException e) {
                e.printStackTrace();
        } finally {
            if (connection != null) {
                try {
                        connection.close();
                } catch (SQLException e) {
                        e.printStackTrace();
                }
            }
        }
        return false;
	}

	public boolean deleteUser(User user) {
		Connection connection = null;
        Statement statement = null; 
        String sql = "delete from users where user_id = " + user.getId();
        try {			
            connection = ConnectionManager.getConnection();
            statement = connection.createStatement();
            int i = statement.executeUpdate(sql);
            if(i > 0){
                  return true;
            }
            else {
                 return false;
            }
        } catch (SQLException e) {
                e.printStackTrace();
        } finally {
            if (connection != null) {
                try {
                        connection.close();
                } catch (SQLException e) {
                        e.printStackTrace();
                }
            }
        }
        return false;
	}
}
