package dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import java.util.Vector;

import model.TeamSummary;
import model.Ticket;
import model.TicketSummary;


public class TicketDao {

	public Vector<Ticket> getAllTickets() {
		ResultSet rs = null;
		Connection connection = null;
		Statement statement = null;
		Vector<Ticket> tickets = new Vector<Ticket>();

		String sql = "select * from tickets";

		try {
			connection = ConnectionManager.getConnection();
			statement = connection.createStatement();
			rs = statement.executeQuery(sql);

			while (rs.next()) {
				Ticket t = new Ticket();
				t.setTicketId(rs.getInt("ticket_id"));
				t.setTicketName(rs.getString("ticket_name"));
				t.setTicketStatus(rs.getString("ticket_status"));
				t.setTicketCreated("");
				t.setTicketClosed("");
				t.setPriority(rs.getInt("ticket_priority"));
				t.setAssignee(rs.getString("assignee"));
				t.setOpened(rs.getTimestamp("ticket_created"));
				t.setClosed(rs.getTimestamp("ticket_closed"));
				tickets.add(t);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (connection != null) {
				try {
					connection.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return tickets;
	}

	public boolean createTicket(Ticket t) {
		Connection connection = null;
		Statement statement = null;
		String sql = "insert into tickets (`ticket_name`, `ticket_closed`, `ticket_created`, `ticket_status`, `assignee`, `ticket_priority`) values"
				+ " ( '"
				+ t.getTicketName()
				+ "',"
				+ " NULL,"
				+ " '"
				+ t.getOpened()
				+ "',"
				+ " '"
				+ t.getTicketStatus()
				+ "',"
				+ " '" + t.getAssignee() + "'," + " '" + t.getPriority() + "')";
		try {
			connection = ConnectionManager.getConnection();
			statement = connection.createStatement();
			int i = statement.executeUpdate(sql);
			if (i > 0) {
				return true;
			} else {
				return false;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (connection != null) {
				try {
					connection.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return false;
	}

	public boolean saveTicket(Ticket t) {
		Connection connection = null;
		Statement statement = null;
		String sql = "update tickets set ticket_status='" + t.getTicketStatus()
				+ "' where ticket_id='" + t.getTicketId() + "'";
		try {
			connection = ConnectionManager.getConnection();
			statement = connection.createStatement();
			int i = statement.executeUpdate(sql);
			if (i > 0) {
				return true;
			} else {
				return false;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (connection != null) {
				try {
					connection.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return false;
	}

	public int getTotalTicketCount() {
		return getAllTickets().size();
	}

	public int getOpenTicketCount() {
		ResultSet rs = null;
		Connection connection = null;
		Statement statement = null;

		String sql = "select count(*) from tickets where ticket_status='open'";

		try {
			connection = ConnectionManager.getConnection();
			statement = connection.createStatement();
			rs = statement.executeQuery(sql);

			rs.next();
			int count = rs.getInt(1);
			return count;

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (connection != null) {
				try {
					connection.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return -1;
	}

	public int getClosedTicketCount() {
		ResultSet rs = null;
		Connection connection = null;
		Statement statement = null;

		String sql = "select count(*) from tickets where ticket_status='closed'";

		try {
			connection = ConnectionManager.getConnection();
			statement = connection.createStatement();
			rs = statement.executeQuery(sql);

			rs.next();
			int count = rs.getInt(1);
			return count;

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (connection != null) {
				try {
					connection.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return -1;
	}

	public boolean deleteTicket(int ticketId) {
		Connection connection = null;
		Statement statement = null;
		String sql = "delete from tickets where ticket_id='" + ticketId + "'";
		try {
			connection = ConnectionManager.getConnection();
			statement = connection.createStatement();
			int i = statement.executeUpdate(sql);
			if (i > 0) {
				return true;
			} else {
				return false;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (connection != null) {
				try {
					connection.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return false;
	}

	public boolean closeTicket(int ticketId) {
		Connection connection = null;
		Statement statement = null;
		String sql = "update tickets set ticket_status='close', ticket_closed = now() where ticket_id='"
				+ ticketId + "'";
		try {
			connection = ConnectionManager.getConnection();
			statement = connection.createStatement();
			int i = statement.executeUpdate(sql);
			if (i > 0) {
				return true;
			} else {
				return false;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (connection != null) {
				try {
					connection.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return false;
	}

	public TicketSummary getTicketSummary() {
		TicketSummary ticketSummary = new TicketSummary();
		ResultSet rs = null;
		Connection connection = null;
		Statement statement = null;

		String sql = "select ticket_status , count(*) from tickets group by ticket_status";

		try {
			connection = ConnectionManager.getConnection();
			statement = connection.createStatement();
			rs = statement.executeQuery(sql);
			while (rs.next()) {
				String status = rs.getString(1);
				int count = rs.getInt(2);
				if ("open".equalsIgnoreCase(status)) {
					ticketSummary.setNoOpen(count);
					ticketSummary
							.setNoTotal(count + ticketSummary.getNoTotal());
				} else if ("close".equalsIgnoreCase(status)) {
					ticketSummary.setNoClose(count);
					ticketSummary
							.setNoTotal(count + ticketSummary.getNoTotal());
				}
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (connection != null) {
				try {
					connection.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return ticketSummary;
	}

	public List<TeamSummary> getTeamSummary() {
		List<TeamSummary> teamSummaryList = new Vector<TeamSummary>();
		ResultSet rs = null;
		Connection connection = null;
		Statement statement = null;

		String sql = "select assignee, SUM(IF (ticket_status = 'open',1,0)) as  open_count, SUM(IF (ticket_status = 'close',1,0)) as  close_count from tickets group by assignee";

		try {
			connection = ConnectionManager.getConnection();
			statement = connection.createStatement();
			rs = statement.executeQuery(sql);
			while (rs.next()) {
				TeamSummary teamSummary = new TeamSummary();
				TicketSummary ticketSummary = new TicketSummary();
				String name = rs.getString(1);
				teamSummary.setMemberName(name);
				int open_count = rs.getInt(2);
				int close_count = rs.getInt(3);
				ticketSummary.setNoOpen(open_count);
				ticketSummary.setNoClose(close_count);
				ticketSummary.setNoTotal(open_count + close_count);
				teamSummary.setSummary(ticketSummary);
				teamSummaryList.add(teamSummary);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (connection != null) {
				try {
					connection.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return teamSummaryList;
	}
}
