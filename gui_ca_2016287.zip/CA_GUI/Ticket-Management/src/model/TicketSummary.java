package model;


public class TicketSummary {
	private int noOpen;
	private int noClose;
	private int noTotal;
	private double currentCost;
	public TicketSummary(int open, int close, int total) {
		this.noOpen = open;
		this.noClose = close;
		this.noTotal = total;
	}
	
	public TicketSummary() {
		this.noOpen = 0;
		this.noClose = 0;
		this.noTotal = 0;
	}
	
	public int getNoOpen() {
		return noOpen;
	}
	public void setNoOpen(int noOpen) {
		this.noOpen = noOpen;
	}
	public int getNoClose() {
		return noClose;
	}
	public void setNoClose(int noClose) {
		this.noClose = noClose;
	}
	public int getNoTotal() {
		return noTotal;
	}
	public void setNoTotal(int noTotal) {
		this.noTotal = noTotal;
	}

	public double getCurrentCost() {
		currentCost = 50.0 * noClose;
		return currentCost;
	}
	
}
