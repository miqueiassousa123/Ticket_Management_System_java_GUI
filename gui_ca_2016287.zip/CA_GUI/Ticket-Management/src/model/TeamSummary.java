package model;

public class TeamSummary {
	String memberName;
	TicketSummary summary;
	public String getMemberName() {
		return memberName;
	}
	public void setMemberName(String memberName) {
		this.memberName = memberName;
	}
	public TicketSummary getSummary() {
		return summary;
	}
	public void setSummary(TicketSummary summary) {
		this.summary = summary;
	}
}
