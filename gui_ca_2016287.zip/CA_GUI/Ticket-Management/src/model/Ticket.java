package model;

import java.sql.Timestamp;

/**
 *
 * @author miqueias
 */
public class Ticket {
    int ticketId;
    String ticketName;
    String ticketStatus;
    String ticketCreated;
    String ticketClosed;
    String assignee;
    int priority;
    java.sql.Timestamp opened;
    java.sql.Timestamp closed;

    public Timestamp getOpened() {
        return opened;
    }

    public void setOpened(Timestamp opened) {
        this.opened = opened;
    }

    public Timestamp getClosed() {
        return closed;
    }

    public void setClosed(Timestamp cloesed) {
        this.closed = cloesed;
    }

    public int getTicketId() {
        return ticketId;
    }

    public void setTicketId(int ticketId) {
        this.ticketId = ticketId;
    }

    public String getTicketName() {
        return ticketName;
    }

    public void setTicketName(String ticketName) {
        this.ticketName = ticketName;
    }

    public String getTicketStatus() {
        return ticketStatus;
    }

    public void setTicketStatus(String ticketStatus) {
        this.ticketStatus = ticketStatus;
    }

    public String getTicketCreated() {
        return ticketCreated;
    }

    public void setTicketCreated(String ticketCreated) {
        this.ticketCreated = ticketCreated;
    }

    public String getTicketClosed() {
        return ticketClosed;
    }

    public void setTicketClosed(String ticketClosed) {
        this.ticketClosed = ticketClosed;
    }

    public String getAssignee() {
        return assignee;
    }

    public void setAssignee(String assignee) {
        this.assignee = assignee;
    }

    public int getPriority() {
        return priority;
    }

    public void setPriority(int priority) {
        this.priority = priority;
    }

    @Override
    public String toString() {
        return "Ticket{" + "ticketId=" + ticketId + ", ticketName=" + ticketName + ", ticketStatus=" + ticketStatus + ", ticketCreated=" + ticketCreated + ", ticketClosed=" + ticketClosed + ", assignee=" + assignee + ", priority=" + priority + '}';
    }
    
    
}
