package model;

public class Priority {
    private int id;
    private String name;

    public Priority(int id) {
        this.id = id;
    }
    
    public Priority(int id, String name) {
        this.id = id;
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

	@Override
	public boolean equals(Object obj) {
		if(obj instanceof Priority) {
			Priority p = (Priority) obj;
			if(p.getId() == this.id) {
				return true;
			}
		}
		return false;
	}

	@Override
	public String toString() {
		return name;
	} 
    
    
}
