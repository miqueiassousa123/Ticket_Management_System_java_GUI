package model;

/**
 *
 * @author miqueias
 */
public class User {
    long id;
    String userName;
    String password;
    int role;
    public static String[] roleLabels = {"Tech Support", "Sys Admin", "Manager"};
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public int getRole() {
		return role;
	}
	public void setRole(int role) {
		this.role = role;
	}
    
}
