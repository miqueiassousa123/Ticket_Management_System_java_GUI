package main;

import model.User;
import view.LoginView;
import controller.LoginContoller;

/**
 *
 * @author miqueias
 */
public class TicketManagementSystem {
      /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        User userModel = new User();
        userModel.setUserName("james");
        userModel.setPassword("1234");
        LoginView view = new LoginView();
        LoginContoller loginController = new LoginContoller(view);
        loginController.setModel(userModel);
        loginController.initController();
    }
}
