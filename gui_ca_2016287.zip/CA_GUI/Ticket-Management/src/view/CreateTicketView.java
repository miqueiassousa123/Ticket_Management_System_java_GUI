package view;

import java.awt.BorderLayout;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;

import model.Priority;
import model.Ticket;

public class CreateTicketView extends JFrame {

	private static final long serialVersionUID = 2376478591012660573L;
	private JPanel contentPane;
	private JTextField txtTicketName;
	private JTextField txtAsignee;
	private JComboBox<Priority> comboPriority;
	private Ticket ticket;
	private JButton btnSave;
	private JButton btnCancel;
	
	/**
	 * Create the frame.
	 */
	public CreateTicketView(Ticket ticket) {
		this.ticket = ticket;
		setTitle("Create Ticket");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		JPanel formPanel = new JPanel();
		contentPane.add(formPanel, BorderLayout.CENTER);
		
		JLabel lblTicketName = new JLabel("Ticket Name : ");
		
		txtTicketName = new JTextField();
		txtTicketName.setColumns(10);
		
		JLabel lblPriority = new JLabel("Priority : ");
		
		comboPriority = new JComboBox<Priority>();
		DefaultComboBoxModel<Priority> comboModel = new DefaultComboBoxModel<Priority>();
		comboModel.addElement(new Priority(0, "Urgent"));
		comboModel.addElement(new Priority(1, "Normal"));
		comboModel.addElement(new Priority(2, "Long Term"));
		comboPriority.setModel(comboModel);
		
		JLabel lblAsignee = new JLabel("Asignee : ");
		
		txtAsignee = new JTextField();
		txtAsignee.setColumns(10);
		GroupLayout gl_formPanel = new GroupLayout(formPanel);
		gl_formPanel.setHorizontalGroup(
			gl_formPanel.createParallelGroup(Alignment.LEADING)
				.addGroup(Alignment.TRAILING, gl_formPanel.createSequentialGroup()
					.addContainerGap(38, Short.MAX_VALUE)
					.addGroup(gl_formPanel.createParallelGroup(Alignment.TRAILING, false)
						.addComponent(lblAsignee, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
						.addComponent(lblPriority, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
						.addComponent(lblTicketName, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
					.addGap(18)
					.addGroup(gl_formPanel.createParallelGroup(Alignment.LEADING, false)
						.addComponent(txtAsignee)
						.addComponent(comboPriority, 0, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
						.addComponent(txtTicketName, GroupLayout.DEFAULT_SIZE, 266, Short.MAX_VALUE))
					.addGap(34))
		);
		gl_formPanel.setVerticalGroup(
			gl_formPanel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_formPanel.createSequentialGroup()
					.addGap(29)
					.addGroup(gl_formPanel.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblTicketName)
						.addComponent(txtTicketName, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(28)
					.addGroup(gl_formPanel.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblPriority)
						.addComponent(comboPriority, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(28)
					.addGroup(gl_formPanel.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblAsignee)
						.addComponent(txtAsignee, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addContainerGap(79, Short.MAX_VALUE))
		);
		formPanel.setLayout(gl_formPanel);
		
		JPanel buttonPanel = new JPanel();
		contentPane.add(buttonPanel, BorderLayout.SOUTH);
		
		btnSave = new JButton("Save");
		buttonPanel.add(btnSave);
		
		btnCancel = new JButton("Cancel");
		buttonPanel.add(btnCancel);
	}

	public Ticket getTicket() {
		ticket.setAssignee(txtAsignee.getText());
		ticket.setTicketName(txtTicketName.getText());
		Priority p = (Priority) comboPriority.getSelectedItem();
		ticket.setPriority(p.getId());
		return ticket;
	}

	public void setTicket(Ticket ticket) {
		this.ticket = ticket;
		if(ticket != null) {
			txtTicketName.setText(ticket.getTicketName());
			txtAsignee.setText(ticket.getAssignee());
			comboPriority.setSelectedItem(new Priority(ticket.getPriority()));
		}
	}

	public JButton getBtnSave() {
		return btnSave;
	}

	public JButton getBtnCancel() {
		return btnCancel;
	}
}
