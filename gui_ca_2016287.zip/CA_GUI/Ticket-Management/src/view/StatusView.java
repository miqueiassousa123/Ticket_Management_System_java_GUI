package view;

import java.awt.BorderLayout;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;

import model.TicketSummary;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class StatusView extends JFrame {

	private static final long serialVersionUID = 5249488884370924096L;
	private JPanel contentPane;
	private JTextField txtTotal;
	private JTextField txtOpen;
	private JTextField txtClosed;
	private TicketSummary ticketSummary;
	private JTextField txtCost;

	/**
	 * Create the frame.
	 * @param ticketSummary 
	 */
	public StatusView(TicketSummary ticketSummary) {
		this.ticketSummary = ticketSummary;
		setTitle("Tickets Status Summary");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 450, 296);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		JPanel panel = new JPanel();
		contentPane.add(panel, BorderLayout.CENTER);
		
		JLabel lblTotalNumberOf = new JLabel("Total Number of Tickets : ");
		
		txtTotal = new JTextField();
		txtTotal.setEditable(false);
		txtTotal.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("Open : ");
		
		txtOpen = new JTextField();
		txtOpen.setEditable(false);
		txtOpen.setColumns(10);
		
		JLabel lblClosed = new JLabel("Closed :");
		
		txtClosed = new JTextField();
		txtClosed.setEditable(false);
		txtClosed.setColumns(10);
		
		JLabel lblCostOfClosed = new JLabel("Cost of Closed Tickets : ");
		
		txtCost = new JTextField();
		txtCost.setText("0.00");
		txtCost.setEditable(false);
		txtCost.setColumns(10);
		GroupLayout gl_panel = new GroupLayout(panel);
		gl_panel.setHorizontalGroup(
			gl_panel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel.createSequentialGroup()
					.addGap(47)
					.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
						.addComponent(lblNewLabel)
						.addComponent(lblClosed)
						.addComponent(lblTotalNumberOf)
						.addComponent(lblCostOfClosed))
					.addGap(69)
					.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
						.addComponent(txtTotal, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(txtClosed, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(txtOpen, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(txtCost, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addContainerGap(99, Short.MAX_VALUE))
		);
		gl_panel.setVerticalGroup(
			gl_panel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel.createSequentialGroup()
					.addGap(36)
					.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel)
						.addComponent(txtOpen, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(18)
					.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblClosed)
						.addComponent(txtClosed, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(18)
					.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblTotalNumberOf)
						.addComponent(txtTotal, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(18)
					.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblCostOfClosed)
						.addComponent(txtCost, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(68))
		);
		panel.setLayout(gl_panel);
		
		JPanel panel_1 = new JPanel();
		contentPane.add(panel_1, BorderLayout.SOUTH);
		
		JButton btnClose = new JButton("Close");
		panel_1.add(btnClose);
		btnClose.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		populateData();
	}

	public void populateData() {
		txtOpen.setText("" + ticketSummary.getNoOpen());
		txtClosed.setText("" + ticketSummary.getNoClose());
		txtTotal.setText("" + ticketSummary.getNoTotal());
		txtCost.setText(ticketSummary.getCurrentCost() + " euro");
	}

	public TicketSummary getTicketSummary() {
		return ticketSummary;
	}

	public void setTicketSummary(TicketSummary ticketSummary) {
		this.ticketSummary = ticketSummary;
		populateData();
	}
}
