package view;

import java.awt.BorderLayout;
import java.util.List;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.JScrollPane;

import model.TeamSummary;

import javax.swing.JTable;

public class TeamView extends JFrame {

	private static final long serialVersionUID = 7891657524332298909L;
	private JPanel contentPane;
	private List<TeamSummary> teamSummary;
	private JTable table;

	/**
	 * Create the frame.
	 */
	public TeamView(List<TeamSummary> teamSummary) {
		this.teamSummary = teamSummary;
		setTitle("Team Member Summary");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 560, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		JScrollPane scrollPane = new JScrollPane();
		contentPane.add(scrollPane, BorderLayout.CENTER);
		
		table = new JTable();
		table.setModel(new DefaultTableModel(
			new Object[][] {
				{null, null, null, null},
			},
			new String[] {
				"New column", "New column", "New column", "New column"
			}
		));
		scrollPane.setViewportView(table);
		refreshList();
	}
	
	public void refreshList() {
		
		DefaultTableModel dtm = new DefaultTableModel(0, 0);

        // add header of the table
        String header[] = new String[] { "Team Member", "Open Tickets", "Closed Tickets",
                    "Total tickets", "Closed Tickets Cost" };

        // add header in table model     
        dtm.setColumnIdentifiers(header);
        //set model into the table object
        table.setModel(dtm);
        
        for(TeamSummary t: teamSummary) {
            
            dtm.addRow(new Object[]{
            		t.getMemberName(), 
            		t.getSummary().getNoOpen() + "", 
            		t.getSummary().getNoClose() + "",
            		t.getSummary().getNoTotal() + "",
            		t.getSummary().getCurrentCost() + " euro"
            });
        }
	}

}
