package view;

import java.awt.BorderLayout;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;

import java.awt.Color;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;

import model.User;

public class LoginView extends JFrame {

	private static final long serialVersionUID = -3672411891893171693L;
	private JPanel contentPane;
	private JTextField txtUsername;
	private JPasswordField txtPassword;
	private JButton btnLogin;
	private User model;

	
	/**
	 * Create the frame.
	 */
	public LoginView() {
		setResizable(false);
		setTitle("User Login");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);

		JPanel panel = new JPanel();
		panel.setBorder(new TitledBorder(null, "Ticket Management System",
				TitledBorder.CENTER, TitledBorder.TOP, null, new Color(30, 144,
						255)));
		contentPane.add(panel, BorderLayout.CENTER);

		JLabel lblUserName = new JLabel("User Name: ");

		txtUsername = new JTextField();
		txtUsername.setColumns(10);

		JLabel lblPassword = new JLabel("Password:");

		txtPassword = new JPasswordField();

		btnLogin = new JButton("Login");
		
		GroupLayout groupLayerPanel = new GroupLayout(panel);
		groupLayerPanel.setHorizontalGroup(
			groupLayerPanel.createParallelGroup(Alignment.TRAILING)
				.addGroup(groupLayerPanel.createSequentialGroup()
					.addContainerGap(59, Short.MAX_VALUE)
					.addGroup(groupLayerPanel.createParallelGroup(Alignment.LEADING, false)
						.addComponent(lblPassword, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
						.addComponent(lblUserName, GroupLayout.DEFAULT_SIZE, 65, Short.MAX_VALUE))
					.addGap(18)
					.addGroup(groupLayerPanel.createParallelGroup(Alignment.LEADING)
						.addComponent(txtPassword, 224, 224, 224)
						.addComponent(txtUsername, GroupLayout.PREFERRED_SIZE, 223, GroupLayout.PREFERRED_SIZE))
					.addGap(57))
				.addGroup(groupLayerPanel.createSequentialGroup()
					.addContainerGap(212, Short.MAX_VALUE)
					.addComponent(btnLogin)
					.addGap(143))
		);
		groupLayerPanel.setVerticalGroup(
			groupLayerPanel.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayerPanel.createSequentialGroup()
					.addGap(50)
					.addGroup(groupLayerPanel.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblUserName)
						.addComponent(txtUsername, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(36)
					.addGroup(groupLayerPanel.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblPassword)
						.addComponent(txtPassword, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(38)
					.addComponent(btnLogin)
					.addContainerGap(41, Short.MAX_VALUE))
		);
		panel.setLayout(groupLayerPanel);
		model = new User();
	}

	public JButton getButton(String action) {
		JButton actionButton = null;
		switch(action) {
			case "login" :
				actionButton = btnLogin;
				break;
			default:
				actionButton = btnLogin;
		}
		return actionButton;
	}

	public User getModel() {
		if(model == null) {
			model = new User();
		}
		model.setUserName(txtUsername.getText());
		model.setPassword(new String(txtPassword.getPassword()));
		return model;
	}

	public void setModel(User model) {		
		this.model = model;
		if(model != null) {
			txtUsername.setText(model.getUserName());
			txtPassword.setText(model.getPassword());
		} else {
			txtUsername.setText("");
			txtPassword.setText("");
		}
		
	}
}
