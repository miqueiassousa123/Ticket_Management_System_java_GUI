package view;

import java.awt.BorderLayout;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import model.Ticket;

public class ManagerView extends MainView {

	private static final long serialVersionUID = -3324772139885188820L;
	private JTable table;
	private JButton btnTeamStatus;
	private JButton btnRefreshList;
	private JButton btnCloseTicket;
	private JButton btnStats;
        private JButton btnShow;

	
	/**
	 * Create the frame.
	 */
	public ManagerView() {
		super();
		setTitle("Ticket Management System - Manager View");		
		btnTeamStatus = new JButton("Team Status");
		topPanel.add(btnTeamStatus);
		
		btnRefreshList = new JButton("Refresh List");
		topPanel.add(btnRefreshList);
		
		btnCloseTicket = new JButton("Close Ticket");
		topPanel.add(btnCloseTicket);
		
		btnStats = new JButton("Status Summary");
		topPanel.add(btnStats);
                
                btnShow = new JButton("Show Diagram");
                topPanel.add(btnShow);
		
		JScrollPane scrollPane = new JScrollPane();
		contentPane.add(scrollPane, BorderLayout.CENTER);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		
		JPanel panel = new JPanel();
		contentPane.add(panel, BorderLayout.SOUTH);
		setContentPane(contentPane);
		JLabel lblNewLabel = new JLabel("Priority :    0 = Urgent, 1 = Normal, 2 = LongTerm");
		panel.add(lblNewLabel);
	}


	public void refreshList(List<Ticket> tickets) {
		DefaultTableModel dtm = new DefaultTableModel(0, 0);

        // add header of the table
        String header[] = new String[] { "Id", "Name", "Status",
                    "Created", "Closed", "Assignee", "Priority" };

        // add header in table model     
        dtm.setColumnIdentifiers(header);
        //set model into the table object
        table.setModel(dtm);
        
        for(Ticket t: tickets) {
            String closed = "";
            if(t.getClosed() != null) {
                closed = t.getClosed().toString();
            }
            
            dtm.addRow(new Object[]{Integer.toString(t.getTicketId())
                    , t.getTicketName()
                    , t.getTicketStatus()
                    , t.getOpened().toString()
                    , closed
                    , t.getAssignee()
                    , Integer.toString(t.getPriority())});
        }
	}
	
	public int[] getSelectedTicketIndex() {
		return table.getSelectedRows();
	}
	
	public JButton getButton(String action) {
		JButton actionButton = null;
		switch(action) {
			case "close" :
				actionButton = btnCloseTicket;
				break;
			case "team" :
				actionButton = btnTeamStatus;
				break;
			case "status" :
				actionButton = btnStats;
				break;
			case "refresh" :
				actionButton = btnRefreshList;
				break;
                        case "diagram" :
                                actionButton = btnShow;
                                break;
			default:
		}
		//check in parent
		if(actionButton == null) {
			actionButton = super.getButton(action);
		}
		return actionButton;
	}
}
