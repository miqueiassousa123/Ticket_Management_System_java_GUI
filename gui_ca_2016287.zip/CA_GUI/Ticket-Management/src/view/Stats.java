package view;

import java.awt.Color;
import java.awt.Graphics;
import javax.swing.JLabel;


public class Stats extends javax.swing.JPanel {
    private static final Color BACKGROUND_COLOR = Color.white;
    private static final Color BAR_COLOR = Color.red;
    private JLabel jLabel1;
    private JLabel jLabel2;
    private JLabel jLabel3;  
    /**
     * Creates new form Stats
     */
    private int[] inputData;
    
    public Stats(final int[] inputData) {
        this.inputData = inputData;
        initComponents();
    }


    protected void paintComponent(final Graphics g) {
        super.paintComponent(g);
        drawBars(g);
    }

    private void drawBars(final Graphics g) {
        int OUTER_MARGIN = 20,
                WIDTH = 400 + 2 * OUTER_MARGIN,
                HEIGHT = 300 + 2 * OUTER_MARGIN;

        g.setColor(BACKGROUND_COLOR);
        g.fillRect(0, 0, WIDTH, HEIGHT);
        Color BAR_COLOR = Color.red;
        g.setColor(BAR_COLOR);
        int barWidth = 20;
        int heightRatio = 10;
        for (int i = 0; i < inputData.length; i++) {
            if(i == 0) {
                heightRatio = 240 / inputData[i];
            }
            int x = OUTER_MARGIN + 60 * i;
            int barHeight = heightRatio * inputData[i];
            int y = 260 - barHeight;
            g.fillRect(x, y, barWidth, barHeight);
            System.out.println(i + ", " + x + ", " + y + ", " + barHeight + ", " + inputData[i]);
        }
    }
    
   
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();

        jLabel1.setText("Total");

        jLabel2.setText("Open");

        jLabel3.setText("Closed");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(jLabel1)
                .addGap(31, 31, 31)
                .addComponent(jLabel2)
                .addGap(18, 18, 18)
                .addComponent(jLabel3)
                .addContainerGap(247, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(264, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(jLabel2)
                    .addComponent(jLabel3))
                .addGap(22, 22, 22))
        );
    }          
}
