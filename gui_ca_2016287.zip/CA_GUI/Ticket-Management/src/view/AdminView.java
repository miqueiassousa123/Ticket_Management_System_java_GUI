package view;

import helper.Utils;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.util.List;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.UIManager;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;

import model.User;

import javax.swing.DefaultComboBoxModel;
import javax.swing.ListSelectionModel;

public class AdminView extends MainView {

	private static final long serialVersionUID = 4355328502971435581L;
	private JTable table;
	private JButton btnRefreshList;
	private JButton btnCreateUser;
	private JButton btnUpdateUser;
	private JButton btnDeleteUser;
	private JTextField txtUsername;
	private JPasswordField txtPassword;
	private JComboBox<String> comboRole;
	private User user;

	/**
	 * Create the frame.
	 */
	public AdminView() {
		super();
		setTitle("Ticket Management System - Admin View");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 539, 364);		
		setContentPane(contentPane);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setViewportBorder(new LineBorder(new Color(0, 0, 0)));
		contentPane.add(scrollPane, BorderLayout.CENTER);
		
		table = new JTable();
		table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		table.setModel(new DefaultTableModel(
			new Object[][] {
				{null, null, null, null},
				{null, null, null, null},
			},
			new String[] {
				"User Id", "Userame", "Password", "Role"
			}
		));
		scrollPane.setViewportView(table);
		
		btnRefreshList = new JButton("Refresh List");
		topPanel.add(btnRefreshList);
		
		btnDeleteUser = new JButton("Delete User");
		topPanel.add(btnDeleteUser);
		
		JPanel panel_6 = new JPanel();
		contentPane.add(panel_6, BorderLayout.SOUTH);
		panel_6.setLayout(new BoxLayout(panel_6, BoxLayout.X_AXIS));
		
		JPanel panel = new JPanel();
		panel_6.add(panel);
		panel.setLayout(new BorderLayout(0, 0));
		
		JPanel panelCreateUser = new JPanel();
		panelCreateUser.setBorder(new TitledBorder(UIManager.getBorder("TitledBorder.border"), "Create or Update User", TitledBorder.CENTER, TitledBorder.TOP, null, new Color(0, 0, 0)));
		panel.add(panelCreateUser, BorderLayout.CENTER);
		GridBagLayout gbl_panelCreateUser = new GridBagLayout();
		gbl_panelCreateUser.columnWidths = new int[]{111, 0, 195, 0};
		gbl_panelCreateUser.rowHeights = new int[] {20, 20, 30};
		gbl_panelCreateUser.columnWeights = new double[]{0.0, 0.0, 0.0, Double.MIN_VALUE};
		gbl_panelCreateUser.rowWeights = new double[]{0.0, 0.0, 0.0};
		panelCreateUser.setLayout(gbl_panelCreateUser);
		
		JLabel lblUsername = new JLabel("Username : ");
		GridBagConstraints gbc_lblUsername = new GridBagConstraints();
		gbc_lblUsername.anchor = GridBagConstraints.EAST;
		gbc_lblUsername.insets = new Insets(0, 0, 5, 5);
		gbc_lblUsername.gridx = 1;
		gbc_lblUsername.gridy = 0;
		panelCreateUser.add(lblUsername, gbc_lblUsername);
		
		txtUsername = new JTextField();
		txtUsername.setColumns(10);
		GridBagConstraints gbc_txtUsername = new GridBagConstraints();
		gbc_txtUsername.anchor = GridBagConstraints.NORTH;
		gbc_txtUsername.fill = GridBagConstraints.HORIZONTAL;
		gbc_txtUsername.insets = new Insets(0, 0, 5, 0);
		gbc_txtUsername.gridx = 2;
		gbc_txtUsername.gridy = 0;
		panelCreateUser.add(txtUsername, gbc_txtUsername);
		
		JLabel lblPassword = new JLabel("Password : ");
		GridBagConstraints gbc_lblPassword = new GridBagConstraints();
		gbc_lblPassword.anchor = GridBagConstraints.EAST;
		gbc_lblPassword.insets = new Insets(0, 0, 5, 5);
		gbc_lblPassword.gridx = 1;
		gbc_lblPassword.gridy = 1;
		panelCreateUser.add(lblPassword, gbc_lblPassword);
		
		txtPassword = new JPasswordField();
		GridBagConstraints gbc_txtPassword = new GridBagConstraints();
		gbc_txtPassword.anchor = GridBagConstraints.NORTH;
		gbc_txtPassword.fill = GridBagConstraints.HORIZONTAL;
		gbc_txtPassword.insets = new Insets(0, 0, 5, 0);
		gbc_txtPassword.gridx = 2;
		gbc_txtPassword.gridy = 1;
		panelCreateUser.add(txtPassword, gbc_txtPassword);
		
		JLabel lblRole = new JLabel("Role : ");
		GridBagConstraints gbc_lblRole = new GridBagConstraints();
		gbc_lblRole.anchor = GridBagConstraints.EAST;
		gbc_lblRole.insets = new Insets(0, 0, 0, 5);
		gbc_lblRole.gridx = 1;
		gbc_lblRole.gridy = 2;
		panelCreateUser.add(lblRole, gbc_lblRole);
		
		comboRole = new JComboBox<String>();
		comboRole.setModel(new DefaultComboBoxModel<String>(User.roleLabels));
		GridBagConstraints gbc_comboRole = new GridBagConstraints();
		gbc_comboRole.anchor = GridBagConstraints.NORTH;
		gbc_comboRole.fill = GridBagConstraints.HORIZONTAL;
		gbc_comboRole.gridx = 2;
		gbc_comboRole.gridy = 2;
		panelCreateUser.add(comboRole, gbc_comboRole);
		
		JPanel buttonPanel = new JPanel();
		panel.add(buttonPanel, BorderLayout.SOUTH);
		
		btnCreateUser = new JButton("Create User");
		buttonPanel.add(btnCreateUser);
		
		btnUpdateUser = new JButton("Update User");
		buttonPanel.add(btnUpdateUser);
	}

	public void refreshList(List<User> users) {
		DefaultTableModel dtm = new DefaultTableModel(0, 0);

        // add header of the table
        String header[] = new String[] { "User Id", "Userame", "Password",
                    "Role" };

        // add header in table model     
        dtm.setColumnIdentifiers(header);
        //set model into the table object
        table.setModel(dtm);
        
        for(User user: users) {
            dtm.addRow(new Object[]{
            		"" + user.getId()
                    , user.getUserName()
                    , user.getPassword()
                    , user.getRole()});
        }
	}
	
	public JButton getButton(String action) {
		JButton actionButton = null;
		switch(action) {
			case "create" :
				actionButton = btnCreateUser;
				break;
			case "update" :
				actionButton = btnUpdateUser;
				break;
			case "delete" :
				actionButton = btnDeleteUser;
				break;
			case "refresh" :
				actionButton = btnRefreshList;
				break;
			default:
		}
		//check in parent
		if(actionButton == null) {
			actionButton = super.getButton(action);
		}
		return actionButton;
	}

	public User getUser() {
		if(user == null) {
			user = new User();
		}
		user.setUserName(txtUsername.getText());
		user.setPassword(new String(txtPassword.getPassword()));
		user.setRole(Utils.getRoleByLabel(comboRole.getSelectedItem().toString()));
		return user;
	}

	public void setUser(User user) {
		this.user = user;
		if(user != null) {
			txtUsername.setText(user.getUserName());
			txtPassword.setText(user.getPassword());
			comboRole.setSelectedItem(Utils.getLabelByRole(user.getRole()));
		} else {
			txtUsername.setText("");
			txtPassword.setText("");
			comboRole.setSelectedIndex(0);
		}
	}
	
	
	public int getSelectedUserIndex() {
		return table.getSelectedRow();
	}
	
}
