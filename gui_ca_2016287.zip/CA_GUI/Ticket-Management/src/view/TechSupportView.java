package view;

import java.awt.BorderLayout;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import model.Ticket;

public class TechSupportView extends MainView {
	private static final long serialVersionUID = 2351032477974251848L;
	private JTable table;
	private JButton btnCreateTicket;
	private JButton btnRefreshList;
	private JButton btnDeleteticket;

	
	/**
	 * Create the frame.
	 */
	public TechSupportView() {
		setTitle("Ticket Management System - Tech Support View");		
		btnCreateTicket = new JButton("Create Ticket");
		topPanel.add(btnCreateTicket);
		
		btnRefreshList = new JButton("Refresh List");
		topPanel.add(btnRefreshList);
		
		btnDeleteticket = new JButton("Delete Ticket");
		topPanel.add(btnDeleteticket);
		
		JScrollPane scrollPane = new JScrollPane();
		contentPane.add(scrollPane, BorderLayout.CENTER);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		
		JPanel panel = new JPanel();
		contentPane.add(panel, BorderLayout.SOUTH);
		setContentPane(contentPane);
		JLabel lblNewLabel = new JLabel("Priority :    0 = Urgent, 1 = Normal, 2 = LongTerm");
		panel.add(lblNewLabel);
	}


	public void refreshList(List<Ticket> tickets) {
		DefaultTableModel dtm = new DefaultTableModel(0, 0);

        // add header of the table
        String header[] = new String[] { "Id", "Name", "Status",
                    "Created", "Closed", "Assignee", "Priority" };

        // add header in table model     
        dtm.setColumnIdentifiers(header);
        //set model into the table object
        table.setModel(dtm);
        
        for(Ticket t: tickets) {
            String closed = "";
            if(t.getClosed() != null) {
                closed = t.getClosed().toString();
            }
            
            dtm.addRow(new Object[]{Integer.toString(t.getTicketId())
                    , t.getTicketName()
                    , t.getTicketStatus()
                    , t.getOpened().toString()
                    , closed
                    , t.getAssignee()
                    , Integer.toString(t.getPriority())});
        }
	}
	
	public int[] getSelectedTicketIndex() {
		return table.getSelectedRows();
	}
	
	public JButton getButton(String action) {
		JButton actionButton = null;
		switch(action) {
			case "delete" :
				actionButton = btnDeleteticket;
				break;
			case "create" :
				actionButton = btnCreateTicket;
				break;
			case "refresh" :
				actionButton = btnRefreshList;
				break;
			default:
		}
		//check in parent
		if(actionButton == null) {
			actionButton = super.getButton(action);
		}
		return actionButton;
	}

}
