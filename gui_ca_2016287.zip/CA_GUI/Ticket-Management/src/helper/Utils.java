package helper;

import model.User;


public class Utils {
    public static java.sql.Timestamp getCurrentTimeStamp() {
    	java.util.Date today = new java.util.Date();
    	return new java.sql.Timestamp(today.getTime());
    }
    
    public static String getLabelByRole(int role) {
    	switch(role) {
    		case 1: return User.roleLabels[0];
    		case 2: return User.roleLabels[1];
    		case 3: return User.roleLabels[2];
    	}
    	return "";
    }
    
    public static int getRoleByLabel(String label) {
    	if (User.roleLabels[0].equals(label)) {
    		return 1;
    	} else if (User.roleLabels[1].equals(label)) {
    		return 2;
    	} else if (User.roleLabels[2].equals(label)) {
    		return 3;
    	} 
    	return 1;
    }
}
